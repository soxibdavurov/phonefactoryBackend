export interface T {
    [key: string]: any
}

export function test() {}