export enum MemberType {
  USER = "USER",
  MOBILESHOP = "MOBILESHOP",
}

export enum MemberStatus {
  ACTIVE = "ACTIVE",
  BLOCK = "BLOCK",
  DELETE = "DELETE",
}
