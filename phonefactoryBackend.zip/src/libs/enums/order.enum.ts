export enum OrderStatus {
    PAUSE = "PAUSE",
    PROCESS = "PROCESS",
    FINISH = "FINISH",
    DELETE = "DELETE",
}