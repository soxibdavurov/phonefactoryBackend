export enum ViewGroup {
    PRODUCT = "PRODUCT", 
}