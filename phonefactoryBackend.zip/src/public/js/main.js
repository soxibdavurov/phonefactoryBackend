console.log("Basic frontend javascript file");
